package com.floatingnotes.app

import android.animation.ValueAnimator
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.core.app.NotificationCompat
import kotlin.math.max
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val EXTRA_TEXT = "text"
        const val CHANNEL = "prompter"
        fun start(c: Context, text: String) {
            val i = Intent(c, OverlayService::class.java).putExtra(EXTRA_TEXT, text)
            c.startForegroundService(i)
        }
        fun stop(c: Context) = c.stopService(Intent(c, OverlayService::class.java))
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private var root: FrameLayout? = null
    private var scroller: ScrollView? = null
    private var textView: TextView? = null
    private var animator: ValueAnimator? = null
    private var playing = false
    private var wpm = 130

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        prefs = Prefs(this)
        wpm = prefs.speedWpm
        startForeground(1, notification())
        val text = intent?.getStringExtra(EXTRA_TEXT) ?: ""
        if (root == null) buildOverlay(text)
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Teleprompter", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Teleprompter running")
            .setContentText("Tap to return to Floating Notes")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun buildOverlay(text: String) {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val lp = WindowManager.LayoutParams(
            dp(320), dp(220),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(80) }

        val container = FrameLayout(this)
        root = container
        container.alpha = prefs.opacity

        val bg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat(); setColor(prefs.bgColor)
        }
        container.background = bg

        // Scrolling text
        scroller = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            setOnTouchListener { _, _ -> true } // manual scroll disabled; drag moves window
        }
        textView = TextView(this).apply {
            setText(text)
            setTextColor(prefs.textColor)
            textSize = prefs.textSizeSp.toFloat()
            setPadding(dp(16), dp(110), dp(16), dp(220))
            setLineSpacing(0f, 1.3f)
        }
        scroller!!.addView(textView)
        container.addView(scroller, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        if (prefs.mirror) container.scaleX = -1f

        // Control bar
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(0x66000000)
            if (prefs.mirror) scaleX = -1f // unflip controls
        }
        fun btn(label: String, onClick: () -> Unit): TextView =
            TextView(this).apply {
                setText(label); setTextColor(Color.WHITE); textSize = 18f
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { onClick() }
            }
        val playBtn = btn("\u25B6") {}
        playBtn.setOnClickListener { if (playing) pause(playBtn) else startCountdownThenPlay(playBtn) }
        controls.addView(btn("\u2212") { changeSpeed(-10, playBtn) })
        controls.addView(playBtn)
        controls.addView(btn("+") { changeSpeed(+10, playBtn) })
        controls.addView(btn("\u21BA") { scroller?.scrollTo(0, 0) })
        controls.addView(btn("\u2715") { stopSelf() })
        container.addView(controls, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM))

        // Drag to move + pinch handle (drag from top area)
        var ix = 0; var iy = 0; var tx = 0f; var ty = 0f
        container.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = lp.x; iy = lp.y; tx = e.rawX; ty = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ix + (e.rawX - tx).roundToInt()
                    lp.y = iy + (e.rawY - ty).roundToInt()
                    wm.updateViewLayout(container, lp); true
                }
                else -> false
            }
        }

        // Resize handle (bottom-right corner)
        val handle = TextView(this).apply {
            setText("\u25E2"); setTextColor(Color.WHITE); textSize = 16f
            setPadding(dp(8), dp(8), dp(8), dp(8))
            if (prefs.mirror) scaleX = -1f
        }
        var iw = 0; var ih = 0; var hx = 0f; var hy = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { iw = lp.width; ih = lp.height; hx = e.rawX; hy = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = max(dp(180), iw + (e.rawX - hx).roundToInt())
                    lp.height = max(dp(120), ih + (e.rawY - hy).roundToInt())
                    wm.updateViewLayout(container, lp); true
                }
                else -> false
            }
        }
        container.addView(handle, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END))

        wm.addView(container, lp)
    }

    private fun changeSpeed(delta: Int, playBtn: TextView) {
        wpm = (wpm + delta).coerceIn(60, 240)
        prefs.speedWpm = wpm
        if (playing) { animator?.cancel(); play(playBtn) } // restart at new speed
    }

    private fun startCountdownThenPlay(playBtn: TextView) {
        val cd = prefs.countdown
        if (cd <= 0) { play(playBtn); return }
        playBtn.text = cd.toString()
        object : CountDownTimer(cd * 1000L, 1000L) {
            override fun onTick(ms: Long) { playBtn.text = ((ms / 1000) + 1).toString() }
            override fun onFinish() { play(playBtn) }
        }.start()
    }

    private fun play(playBtn: TextView) {
        val tv = textView ?: return
        val sc = scroller ?: return
        val words = tv.text.split(Regex("\\s+")).size
        val totalPx = (tv.height - sc.height).coerceAtLeast(1)
        val totalMs = (words / wpm.toFloat()) * 60_000f
        val remaining = 1f - sc.scrollY / totalPx.toFloat()
        animator = ValueAnimator.ofInt(sc.scrollY, totalPx).apply {
            duration = (totalMs * remaining).roundToInt().coerceAtLeast(500).toLong()
            interpolator = LinearInterpolator()
            addUpdateListener { sc.scrollTo(0, it.animatedValue as Int) }
            start()
        }
        playing = true
        playBtn.text = "\u23F8"
    }

    private fun pause(playBtn: TextView) {
        animator?.cancel(); playing = false; playBtn.text = "\u25B6"
    }

    override fun onDestroy() {
        animator?.cancel()
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        Prefs(this).let { it.sessionCount = it.sessionCount + 1 }
        super.onDestroy()
    }
}
