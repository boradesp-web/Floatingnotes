package com.floatingnotes.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.compose.*
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AppNav() } }
    }
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(nav) }
        composable("edit/{id}") { b ->
            EditorScreen(nav, b.arguments?.getString("id")?.toLongOrNull() ?: -1L)
        }
        composable("guide") { GuideScreen(nav) }
    }
}

/* ---------------- HOME ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).scripts() }
    val scripts by dao.all().collectAsStateWithLifecycle(emptyList())
    val scope = rememberCoroutineScope()

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
            val title = text.lineSequence().firstOrNull()?.take(40)?.ifBlank { "Imported" } ?: "Imported"
            dao.upsert(Script(title = title, body = text))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Floating Notes") },
                actions = {
                    IconButton(onClick = { importLauncher.launch(arrayOf("text/plain")) }) {
                        Icon(Icons.Default.FileOpen, "Import")
                    }
                    IconButton(onClick = { nav.navigate("guide") }) {
                        Icon(Icons.Default.HelpOutline, "Guide")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { nav.navigate("edit/-1") }) {
                Icon(Icons.Default.Add, "New")
            }
        }
    ) { pad ->
        if (scripts.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text("No scripts yet.\nTap + to create or \u2b06 to import a .txt",
                    color = Color.Gray, lineHeight = 22.sp)
            }
        } else LazyColumn(Modifier.padding(pad)) {
            items(scripts, key = { it.id }) { s ->
                ListItem(
                    headlineContent = { Text(s.title, maxLines = 1) },
                    supportingContent = { Text(s.body.take(60), maxLines = 1, color = Color.Gray) },
                    trailingContent = {
                        IconButton(onClick = { scope.launch { dao.delete(s) } }) {
                            Icon(Icons.Default.Delete, "Delete", tint = Color.Gray)
                        }
                    },
                    modifier = Modifier.clickable { nav.navigate("edit/${s.id}") }
                )
                HorizontalDivider()
            }
        }
    }
}

/* ---------------- EDITOR ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(nav: NavController, id: Long) {
    val ctx = LocalContext.current
    val dao = remember { AppDb.get(ctx).scripts() }
    val prefs = remember { Prefs(ctx) }
    val scope = rememberCoroutineScope()

    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var loadedId by remember { mutableStateOf(id) }
    var showSettings by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (id > 0) dao.byId(id)?.let { title = it.title; body = it.body }
    }

    fun save(onDone: (Long) -> Unit = {}) = scope.launch {
        val t = title.ifBlank { "Untitled" }
        val s = Script(id = if (loadedId > 0) loadedId else 0, title = t, body = body)
        val newId = dao.upsert(s)
        if (loadedId <= 0) loadedId = newId
        onDone(loadedId)
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        ctx.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(body) }
        Toast.makeText(ctx, "Exported", Toast.LENGTH_SHORT).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (id > 0) "Edit script" else "New script") },
                navigationIcon = {
                    IconButton(onClick = { save(); nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { exportLauncher.launch("${title.ifBlank { "script" }}.txt") }) {
                        Icon(Icons.Default.Share, "Export")
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Tune, "Settings")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    save {
                        if (!Settings.canDrawOverlays(ctx)) {
                            Toast.makeText(ctx,
                                "Allow \u201cDisplay over other apps\u201d for Floating Notes, then press Play again",
                                Toast.LENGTH_LONG).show()
                            ctx.startActivity(Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${ctx.packageName}")))
                        } else {
                            OverlayService.start(ctx, body)
                            Toast.makeText(ctx, "Prompter floating \u2014 switch to any app",
                                Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                icon = { Icon(Icons.Default.PlayArrow, null) },
                text = { Text("Float") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("Title") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(body, { body = it }, label = { Text("Your script") },
                modifier = Modifier.fillMaxWidth().weight(1f))
            val words = body.split(Regex("\\s+")).count { it.isNotBlank() }
            Text("$words words \u00b7 ~${(words / prefs.speedWpm.toFloat() * 60).toInt()}s at ${prefs.speedWpm} wpm",
                color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }

    if (showSettings) SettingsSheet(prefs) { showSettings = false }
}

/* ---------------- SETTINGS SHEET ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(prefs: Prefs, onDismiss: () -> Unit) {
    var wpm by remember { mutableFloatStateOf(prefs.speedWpm.toFloat()) }
    var size by remember { mutableFloatStateOf(prefs.textSizeSp.toFloat()) }
    var opacity by remember { mutableFloatStateOf(prefs.opacity) }
    var mirror by remember { mutableStateOf(prefs.mirror) }
    var countdown by remember { mutableIntStateOf(prefs.countdown) }
    var textColor by remember { mutableIntStateOf(prefs.textColor) }
    var bgColor by remember { mutableIntStateOf(prefs.bgColor) }

    val textColors = listOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFF80DEEA, 0xFFA5D6A7, 0xFFFF8A80).map { it.toInt() }
    val bgColors = listOf(0xCC000000, 0xCC102027, 0xCC1A237E, 0xCC004D40, 0xCCFFFFFF).map { it.toInt() }

    ModalBottomSheet(onDismissRequest = {
        prefs.speedWpm = wpm.toInt(); prefs.textSizeSp = size.toInt()
        prefs.opacity = opacity; prefs.mirror = mirror; prefs.countdown = countdown
        prefs.textColor = textColor; prefs.bgColor = bgColor
        onDismiss()
    }) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text("Prompter settings", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))

            Text("Speed: ${wpm.toInt()} wpm")
            Slider(wpm, { wpm = it }, valueRange = 60f..240f)

            Text("Text size: ${size.toInt()} sp")
            Slider(size, { size = it }, valueRange = 16f..48f)

            Text("Window opacity: ${(opacity * 100).toInt()}%")
            Slider(opacity, { opacity = it }, valueRange = 0.3f..1f)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Mirror mode (for rigs)", Modifier.weight(1f))
                Switch(mirror, { mirror = it })
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Countdown", Modifier.weight(1f))
                listOf(0, 3, 5).forEach { c ->
                    FilterChip(selected = countdown == c, onClick = { countdown = c },
                        label = { Text(if (c == 0) "Off" else "${c}s") },
                        modifier = Modifier.padding(start = 6.dp))
                }
            }

            Spacer(Modifier.height(8.dp))
            Text("Text color")
            Row { textColors.forEach { c -> ColorDot(c, c == textColor) { textColor = c } } }
            Spacer(Modifier.height(8.dp))
            Text("Background")
            Row { bgColors.forEach { c -> ColorDot(c, c == bgColor) { bgColor = c } } }
        }
    }
}

@Composable
fun ColorDot(color: Int, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.padding(6.dp).size(if (selected) 40.dp else 32.dp)
        .background(Color(color), RoundedCornerShape(50)).clickable { onClick() })
}

/* ---------------- GUIDE ---------------- */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuideScreen(nav: NavController) {
    Scaffold(topBar = {
        TopAppBar(title = { Text("How to use") }, navigationIcon = {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
            }
        })
    }) { pad ->
        Column(Modifier.padding(pad).padding(20.dp)) {
            listOf(
                "1. Create or import" to "Type your script or import a .txt file from the home screen.",
                "2. Customize" to "Open settings (\u2699) to set speed, text size, colors, opacity, mirror mode and countdown.",
                "3. Allow overlay" to "First time only: allow \u201cDisplay over other apps\u201d when asked. On Xiaomi/MIUI also enable \u201cDisplay pop-up windows\u201d in app permissions.",
                "4. Float & present" to "Tap Float, switch to your camera or any app, press \u25B6. Drag to move, pull the corner to resize, \u00b1 to adjust speed live."
            ).forEach { (t, b) ->
                Text(t, style = MaterialTheme.typography.titleMedium)
                Text(b, color = Color.Gray, modifier = Modifier.padding(bottom = 16.dp))
            }
            Text("Floating Notes is 100% free. No signup, no subscriptions, no purchases \u2014 ever.",
                style = MaterialTheme.typography.bodyMedium)
        }
    }
}
