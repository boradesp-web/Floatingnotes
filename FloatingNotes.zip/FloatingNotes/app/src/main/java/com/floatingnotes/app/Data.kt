package com.floatingnotes.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "scripts")
data class Script(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface ScriptDao {
    @Query("SELECT * FROM scripts ORDER BY updatedAt DESC")
    fun all(): Flow<List<Script>>

    @Query("SELECT * FROM scripts WHERE id = :id")
    suspend fun byId(id: Long): Script?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(s: Script): Long

    @Delete
    suspend fun delete(s: Script)
}

@Database(entities = [Script::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun scripts(): ScriptDao

    companion object {
        @Volatile private var i: AppDb? = null
        fun get(c: Context): AppDb = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "fn.db")
                .build().also { i = it }
        }
    }
}

/** Prompter settings persisted in SharedPreferences. */
class Prefs(c: Context) {
    private val p = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    var speedWpm: Int
        get() = p.getInt("wpm", 130); set(v) = p.edit().putInt("wpm", v).apply()
    var textSizeSp: Int
        get() = p.getInt("size", 28); set(v) = p.edit().putInt("size", v).apply()
    var textColor: Int
        get() = p.getInt("tc", 0xFFFFFFFF.toInt()); set(v) = p.edit().putInt("tc", v).apply()
    var bgColor: Int
        get() = p.getInt("bg", 0xCC000000.toInt()); set(v) = p.edit().putInt("bg", v).apply()
    var opacity: Float
        get() = p.getFloat("op", 0.85f); set(v) = p.edit().putFloat("op", v).apply()
    var mirror: Boolean
        get() = p.getBoolean("mir", false); set(v) = p.edit().putBoolean("mir", v).apply()
    var countdown: Int
        get() = p.getInt("cd", 3); set(v) = p.edit().putInt("cd", v).apply()
    var sessionCount: Int
        get() = p.getInt("sess", 0); set(v) = p.edit().putInt("sess", v).apply()
}
