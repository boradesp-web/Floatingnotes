# Floating Notes — Free Floating Teleprompter (Android)

100% free. No signup. No subscriptions. No in-app purchases. Ever.

## Open & run
1. Install Android Studio (Koala or newer).
2. File > Open > select this folder. Let Gradle sync (downloads dependencies).
3. Plug in a phone with USB debugging, press Run.

## Before Play Store release
- Add a real launcher icon (Image Asset in Android Studio).
- Test on Xiaomi/Samsung: MIUI needs "Display pop-up windows" permission too.
- Build > Generate Signed App Bundle (.aab).

## Structure
- `MainActivity.kt` — Compose UI: script list, editor, settings sheet, guide
- `OverlayService.kt` — foreground service; floating window with auto-scroll, drag, resize, mirror, countdown, live speed
- `Data.kt` — Room DB (scripts) + SharedPreferences (settings)
